package question2;

public abstract class Stack{

    
	abstract int push(int x);
	abstract int pop();
	abstract void display();
}